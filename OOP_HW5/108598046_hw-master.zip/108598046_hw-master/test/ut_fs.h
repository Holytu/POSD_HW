#ifndef UT_FS_H
#define UT_FS_H

#include <sys/stat.h>

#include "../src/file.h"
#include "../src/folder.h"
#include "../src/iterator.h"
#include "../src/node.h"
#include "../src/null_iterator.h"
#include "../src/utilities.h"

using namespace std;

class NodeTest : public :: testing :: Test {
protected:
    void SetUp()
    {
        hw = new Folder("test/test_folder/hw");
        a_out = new File("test/test_folder/hw/a.out");
        hw1_cpp = new File("test/test_folder/hw/hw1.cpp");
        hello_txt= new File("test/test_folder/hello.txt");
        test_folder= new Folder("test/test_folder");

        hw->addChild(a_out);
        hw->addChild(hw1_cpp);
        test_folder->addChild(hello_txt);
        test_folder->addChild(hw);
    }

    void TearDown()
    {
        delete hw;
        delete a_out;
        delete hw1_cpp;
        delete hello_txt;
        delete test_folder;
    }

    Folder* hw;
    Node* a_out;
    Node* hw1_cpp;
    File* hello_txt;
    Node* test_folder;
};

TEST(FileTest, First)
{
    struct stat st;
    ASSERT_EQ(0, stat("test/test_folder/hello.txt", &st));
    int size = st.st_size;
    ASSERT_EQ(14, size);

}

TEST_F(NodeTest, First) {
  ASSERT_EQ(14, hello_txt->size());
}
/*
TEST_F(NodeTest, Second)
{
  Iterator * it= test_folder->createIterator();
  ASSERT_EQ(128, test_folder->size());

  it->first();
  ASSERT_EQ(14, it->currentItem()->size());

  it->next();
  ASSERT_EQ(128, it->currentItem()->size());
}
*/

TEST_F(NodeTest, One)
{
    Iterator * it= test_folder->createIterator();
    it->first();
    it->next();

    ASSERT_EQ(hw, it->currentItem());
}
TEST_F(NodeTest, TWO)
{
    Iterator * it = test_folder->createIterator();
    it->first();
    //it->DisplayNodeName();
    it->next();
    //it->DisplayNodeName();

    Utilities ut;
    //cout << ut.listNode(test_folder) << endl;
    ASSERT_EQ("hello.txt hw", ut.listNode(test_folder));
    //cout << ut.findNode(test_folder, "hello.txt") << endl;
}
TEST_F(NodeTest, Three)
{
    Utilities ut;
    //cout << ut.findNode(a_out, "a.out") << endl;
    ASSERT_EQ("a.out", ut.findNode(a_out, "a.out"));
}
TEST_F(NodeTest, Fourth)
{
    Utilities ut;
    //cout << ut.findNode(hw,"a.out") << endl;
    ASSERT_EQ("./a.out", ut.findNode(hw,"a.out"));
}
TEST_F(NodeTest, Fifth)
{
    Utilities ut;
    //cout << ut.findNode(test_folder,"a.out") << endl;
    ASSERT_EQ("./hw/a.out",ut.findNode(test_folder,"a.out"));
}
TEST_F(NodeTest, Sixth)
{
    Utilities ut;
    //cout << ut.findNode(test_folder,"hw") << endl;
    ASSERT_EQ("./hw",ut.findNode(test_folder,"hw"));
}

#endif
