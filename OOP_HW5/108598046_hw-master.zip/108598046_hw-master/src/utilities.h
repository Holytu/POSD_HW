#ifndef UTILITIES_H
#define UTILITIES_H

#include "node.h"
#include "folder.h"
#include <sys/stat.h>
using namespace std;

class Utilities
{
public:
    string listNode(Node *node)
    {
        Folder* f = dynamic_cast<Folder*> (node);
        string FolderFiles = "";
        vector<string> sortNode;

        if(f != nullptr)
        {
            Iterator* it = f->createIterator();

            for ( it->first() ; !it->isDone() ; it->next() )
            {
                sortNode.push_back(it->getNodeName());
            }

            sort( sortNode.begin() , sortNode.end() );

            for ( int i = 0; i < sortNode.size() ; i++ )
            {
                FolderFiles = FolderFiles + sortNode[i] + " ";
            }

            FolderFiles.erase(FolderFiles.size() - 1 , 1 );

        }
        else
        {
            throw(std::string("Not a directory"));
        }

        return FolderFiles;
    }

    string findNode(Node *node, string name)
    {
        fd = dynamic_cast<Folder*> (node);

        if(fd != nullptr)
        {
            Iterator* iter = fd->createIterator();
            vector<string> vec;
            DiveInFolders(node, name, &vec); // v

            for (int i = 0 ; i < vec.size() ; i++ )
            {
                vec[i].erase(0, node->return_Path().size());
            }

            string str = "";
            for (int i = 0 ; i < vec.size() ; i++ )
            {
                str = str + "." + vec[i];
                if(i < vec.size() - 1 )
                {
                    str = str + "\n";
                }
            }
            return str;
        }
        else
        {
            if(node->name() == name)
            {
                return "" + name;
            }
        }
        return "";
    }

    //void DiveInFolders(string name, vector<string> *vec)
    void DiveInFolders(Node* node, string name, vector<string> *vec)
    {
        Iterator *iter = node->createIterator(); // ?
        //cout << "enter here?!?!?!" << endl;

        for( iter->first() ; !iter->isDone() ; iter->next() ) // ?
        {
            if(iter->currentItem()->name() == name )
            {
                vec->push_back(iter->currentItem()->return_Path());
            }

            struct stat st;
            stat(iter->currentItem()->return_Path().c_str(), &st);

            if(S_ISDIR(st.st_mode) == 1 )
            {
                DiveInFolders(iter->currentItem(), name, vec);
            }
        }
    }

private:
    //Iterator *iter = nullptr;
    struct stat _st;
    Folder* fd = nullptr;
};

#endif
