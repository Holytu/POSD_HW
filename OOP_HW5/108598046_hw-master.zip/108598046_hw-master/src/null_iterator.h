#ifndef NULL_ITERATOR_H
#define NULL_ITERATOR_H

using namespace std;

class NullIterator:public Iterator{
public:
  bool isDone()
  {
    return true;
  }

  Node* currentItem()
  {
      throw(string("no child member"));
      //return nullptr;
  }

  void first()
  {
      throw(string("no child member"));
  }

  void next()
  {
      throw(string("no child member"));
  }

  void DisplayNodeName(){}

  std::string getNodeName()
  {
      return "";
  }

  int getMapSize()
  {
      return 0;
  }
};

#endif
