#ifndef FOLDER_H
#define FOLDER_H

#include <string>
#include <sys/stat.h>
#include <vector>
#include <map>

#include "iterator.h"
#include "node.h"
using namespace std;

class Folder: public Node {

public:

  class FolderIterator:public Iterator {
  public:
    FolderIterator(Folder * f): _f(f) {}

    void first() {
      _current = _f->_v.begin();
    }

    Node* currentItem() {
      if(this->isDone() == true)
      {
          throw(string("No current item!"));
      }
      return _current->second;
      //return nullptr;
    }

    void next() {
      if(this->isDone() == true)
      {
          throw(string("Moving past the end!"));
      }
      _current++;
    }

    bool isDone() {
      return _current == _f->_v.end();
      //return true;
    }

    void DisplayNodeName()
    {
        //cout << "FolderIterator's DisplayNodeName() : " << _current->first << endl;
    }

    string getNodeName()
    {
        return _current->first;
    }

    int getMapSize()
    {
        return _f->_v.size();
    }


  private:
    Folder * _f;
    std::map<string ,Node*>::iterator _current;
    //std::vector<Node*>::iterator _current;
};

public:
  Folder(std::string path): Node(path)
  {
      stat(path.c_str(), &_st);

      if(S_ISDIR(_st.st_mode) == 0)
      {
         throw(string("It is not Folder!"));
      }
  }

  ~Folder(){};

  Node* getChild(string filename)
  {
      return _v[filename];
  }

  void addChild(Node* child) {
      //cout << "Name : " << this->name() << ", child : " << child->name() << endl;
    _v.insert( std::pair<string, Node*>(child->name() , child) );
    //_v.push_back(child);
  }

  Iterator * createIterator() {
      //cout << "In Folder's function, Iterator * createIterator()" << endl;
      return new FolderIterator(this);
  }

  int getVectorSize()
  {
      return _v.size();
  }

private:
  //std::vector<Node*> _v;
  std::map<string, Node*> _v;
  string _name = "";
  struct stat _st;
};
#endif
