#ifndef NODE_H
#define NODE_H

#include <string>
#include <sys/stat.h>

#include "iterator.h"
#include "null_iterator.h"

using namespace std;

class Node {

public:
  Node(std::string path): _path(path) {
    stat(_path.c_str(), &_st);

    if(stat(_path.c_str(), &_st) == -1)
    {
        throw(string("Node is not exist!"));
    }
  }
  virtual ~Node(){};

  int size() {
    return _st.st_size;
  }

  virtual string name() //const = 0;
  {
    int i;
    for ( i = _path.size() - 1 ; _path[i] != '/' ; i-- ) {}

    string str = _path.substr(i+1, _path.size() - 1);

    return str;
  }
  virtual Node* getChild(string filename)
  {
      return nullptr;
  }

  virtual void addChild(Node* child) {
    throw(std::string("Invalid add!"));
  }

  virtual Iterator* createIterator() = 0;
  /*{
      return nullptr;
  }*/

  virtual string return_Path()
  {
      return _path;
  }

  virtual int getVectorSize()
  {
      return 0;
  }

private:
  std::string _path;
  struct stat _st;
};


#endif
